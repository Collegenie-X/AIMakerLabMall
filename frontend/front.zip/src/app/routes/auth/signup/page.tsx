// 회원가입 페이지
// 사용자 회원가입 폼과 처리 로직

export default function SignupPage() {
  return (
    <div>
      <h1>회원가입</h1>
      {/* 회원가입 폼 컴포넌트 */}
    </div>
  );
} 