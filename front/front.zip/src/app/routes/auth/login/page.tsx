// 로그인 페이지
// 사용자 로그인 폼과 인증 처리 로직

export default function LoginPage() {
  return (
    <div>
      <h1>로그인</h1>
      {/* 로그인 폼 컴포넌트 */}
    </div>
  );
} 