// 상품 목록 페이지
// 상품 리스트와 필터링, 정렬 기능 제공

export default function ProductsPage() {
  return (
    <div>
      <h1>상품 목록</h1>
      {/* 상품 필터 */}
      {/* 상품 리스트 컴포넌트 */}
    </div>
  );
} 